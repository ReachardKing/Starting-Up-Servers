client_script {"PrioprityStatus.lua"}
server_script {"PrioprityStatus_server.lua"}