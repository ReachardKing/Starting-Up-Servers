
local policeMenu = {
    {type= 26, hash = 1581098148, x = -458.34, y = 6032.36, z= 31.49}, --  Paleto Station
    {type= 26, hash = 1581098148, x = 458.009, y = -1017.29, z = 28.26}, -- MRPD Station Gates
    {type= 26, hash = 1581098148, x = 1860.11, y = 3681.78, z = 33.8}, -- Sandy Station
    {type= 26, hash = 1581098148, x = 864.89, y = -1337.49, z = 26.03}, -- Lamesa Station
    {type= 26, hash = 1581098148, x = -1125.53, y = -832.96, z = 13.37}, -- Vespucci Stations
    {type= 26, hash = 1581098148, x = 535.85, y = -21.64, z= 70.63}, -- Vinwood Station
}

Citizen.CreateThread(function()        
    
    RequestModel(GetHashKey("s_m_y_cop_01"))
    while not HasModelLoaded(GetHashKey("s_m_y_cop_01")) do
        RequestModel(GetHashKey("s_m_y_cop_01"))
        Wait(1)
    end

    loadAnimDict("mini@strip_club@idles@bouncer@base")
    RequestAnimDict("mini@strip_club@idles@bouncer@base")
    while not HasAnimDictLoaded("mini@strip_club@idles@bouncer@base") do
        Wait(1)
    end
    
    for _, IsItems in pairs(policeMenu) do
        Policeped = CreatePed(IsItems.type, IsItems.hash, IsItems.x, IsItems.y, IsItems.z, false, true)
        SetEntityHeading(Policeped, 98.50)
        FreezeEntityPosition(Policeped, true)
        SetEntityInvincible(Policeped, true)
        SetBlockingOfNonTemporaryEvents(Policeped, true)
        TaskPlayAnim(Policeped, "mini@strip_club@idles@bouncer@base","base", 8.0, 0.0, -1, 1, 0, 0, 0, 0)
    end
end)

function loadAnimDict(dict)
    RequestAnimDict(dict)
    while (not HasAnimDictLoaded(dict)) do        
        Citizen.Wait(1)
    end
end