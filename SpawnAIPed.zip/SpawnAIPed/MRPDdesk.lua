
local paycheckped = {
    {type= 4, hash=-912318012, x = -448.41, y= 6012.74, z=31.716}, -- Front disk of Paleto
    {type= 4, hash=-912318012, x = 441.0927, y =-978.859, z =30.689}, -- Front desk of MRPD
    {type= 4, hash=-912318012, x = 1853.2723, y = 3689.1667, z=34.258}, -- Front desk of SANDY
}

Citizen.CreateThread(function()        
    
    RequestModel(GetHashKey("a_m_y_business_01"))
    while not HasModelLoaded(GetHashKey("a_m_y_business_01")) do
        RequestModel(GetHashKey("a_m_y_business_01"))
        Wait(1)
    end

    for _, IsItem in pairs(paycheckped) do
        paycheck = CreatePed(IsItem.type, IsItem.hash, IsItem.x, IsItem.y, IsItem.z, false, true) -- Front desk of MRPD
        SetEntityHeading(paycheck, 181.90)
        FreezeEntityPosition(paycheck, true)
        SetEntityInvincible(paycheck, true)
        SetBlockingOfNonTemporaryEvents(paycheck, true)
    end
end)

Citizen.CreateThread( function()
    -- Ped Interaction
    while true do
        Citizen.Wait(0)
        local pl = GetEntityCoords(GetPlayerPed(-1))
        if (Vdist(pl.x, pl.y, pl.z, 1853.2723, 3689.1667, 34.258) < 3.0) then            
            DrawText3Ds(1853.2723, 3689.1667, 34.258, "Here to collect  pay check")
            if IsControlJustReleased(1, 360) then
                math.random(20000, 30000)
                notify("Collecting your pay check")
            end
        elseif (Vdist2(pl.x, pl.y, pl.z, 441.0927, -978.859, 30.689) < 3.0) then
            DrawText3Ds(441.0927, -978.859, 30.689, "Here to collect  pay check") 
            if IsControlJustReleased(1, 360) then
                math.random(30000, 20000)
                notify("Collecting your pay check")
            end
        elseif(Vdist2(pl.x, pl.y, pl.z, -448.41, 6012.74, 31.716)< 3.0) then
            DrawText3Ds(-448.41, 6012.74, 31.716, "Here to collect  pay check")
            if IsControlJustPressed(1, 360) then
                math.random()
            end
        end
    end
end)

-- Citizen.CreateThread(function()        
--     RequestModel(GetHashKey("a_m_y_business_01"))
--     while not HasModelLoaded(GetHashKey("a_m_y_business_01")) do
--         Wait(1)
--     end
--     for _, IsItem2 in pairs(paycheckped) do
--         paycheck = CreatePed(IsItem2.type, IsItem2.hash, IsItem2.x, IsItem2.z, false, true) -- Sandy shores
--         SetEntityHeading(paycheck, )
--         FreezeEntityPosition(paycheck, true)
--         SetEntityInvincible(paycheck, true)
--     end
-- end)