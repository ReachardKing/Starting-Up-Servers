fx_version 'bodacious'

game 'gta5'

client_scripts {
    "export.lua",
    "Functions.lua",
    "MRPDdesk.lua",
    "SpawnPed.lua",
}